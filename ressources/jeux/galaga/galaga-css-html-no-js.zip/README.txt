A Pen created at CodePen.io. You can find this one at https://codepen.io/dayvson009/pen/pNMQag.

 Jogo feito com html e css, não foi usado nenhum Javascript no código.