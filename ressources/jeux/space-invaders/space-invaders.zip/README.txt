A Pen created at CodePen.io. You can find this one at https://codepen.io/adelciotto/pen/BHuGL.

 A simple space invaders game that I wrote during my early university years.  I apologise for the quality of the code and missing gameplay features. Press left and right arrow keys to move and the X key to fire.