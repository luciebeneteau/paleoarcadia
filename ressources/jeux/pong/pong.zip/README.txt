A Pen created at CodePen.io. You can find this one at https://codepen.io/legosushi2006/pen/PQvNaN.

 This is my version of pong, the old arcade game, enjoy!